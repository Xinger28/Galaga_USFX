// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "NaveEnemigaJefe.h"
#include "NaveEnemigaJefeNv1.generated.h"

/**
 * 
 */
UCLASS()
class GALAGA_USFX_API ANaveEnemigaJefeNv1 : public ANaveEnemigaJefe
{
	GENERATED_BODY()
	
};
